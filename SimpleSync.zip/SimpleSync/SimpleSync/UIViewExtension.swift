//
//  UIViewExtension.swift
//  SwiftDemo810
//
//  Created by 胡剑 on 16/8/10.
//  Copyright © 2016年 Karl0n. All rights reserved.
//

import Foundation
import UIKit
private var rt_color = ""
extension UIView {
    
    func viewAddTarget(target : AnyObject,action : Selector) {
        
        let tap = UITapGestureRecognizer(target: target, action: action)
        self.userInteractionEnabled = true
        self.addGestureRecognizer(tap)
    }
    
    var bcolor:UIColor
        {
      get
      {
           return (objc_getAssociatedObject(self, &rt_color) as? UIColor)!
       }
        
        set
        {
             objc_setAssociatedObject(self, &rt_color, newValue, objc_AssociationPolicy.OBJC_ASSOCIATION_ASSIGN)
            self.backgroundColor=newValue;
        }
    }
    
    var left: CGFloat {
        get {
            return self.frame.origin.x
        }
        set {
            var frame = self.frame
            frame.origin.x = newValue
            self.frame = frame
        }
    }
    var right: CGFloat {
        get {
            return self.frame.origin.x + self.bounds.width
        }
        set {
            var frame = self.frame
            frame.origin.y = newValue
            self.frame = frame
        }
    }
    var top: CGFloat {
        get {
            return self.frame.origin.y
        }
    }
    var bottom: CGFloat {
        get {
            return self.frame.origin.y + self.bounds.height
        }
    }
    var width: CGFloat {
        get {
            return self.bounds.width
        }
        
        set {
            var frame = self.frame
            frame.size.width = newValue
            self.frame = frame
        }
    }
    var height: CGFloat {
        get {
            return self.bounds.height
        }
        
        set {
            var frame = self.frame
            frame.size.height = newValue
            self.frame = frame
        }
    }
    
    var size : CGSize {
        get {
            return self.frame.size
        }
        
        set {
            var frame = self.frame
            frame.size = newValue
            self.frame = frame
        }
    }
    
    var origin : CGPoint {
        get {
            return self.frame.origin
        }
        
        set {
            var frame = self.frame
            frame.origin = newValue
            self.frame = frame
        }
    }
    
}

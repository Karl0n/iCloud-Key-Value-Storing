//
//  ViewController.swift
//  SimpleSync
//
//  Created by 胡剑 on 16/8/29.
//  Copyright © 2016年 Karl0n. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    var textview:UITextView!
    
    var SynButton:UIButton!
    
    var iCloudKeyStore: NSUbiquitousKeyValueStore! = NSUbiquitousKeyValueStore()
    
    let iCloudTextKey = "iCloudTextKey"

    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.title="Simple Sync"
        
        //用于显示iCloud同步回来的字符串的
        self.textview = UITextView.init(frame: CGRectMake(10,64+10,kDeviceWidth-20,100))
        self.textview.layer.borderColor=UIColor.lightGrayColor().CGColor
        self.textview.layer.borderWidth=1
        self.textview.textAlignment=NSTextAlignment.Left
        self.textview.scrollEnabled=false
        self.textview.editable=false
        self.textview.layer.masksToBounds=true
        self.view.addSubview(self.textview)
        
        
        //点击同步按钮
        self.SynButton = UIButton.init(type: UIButtonType.Custom)
        self.SynButton.frame=CGRectMake(0.5*(kDeviceWidth-100),self.textview.bottom+30,100,30)
        self.SynButton.bcolor=UIColor.clearColor()
        self.SynButton.layer.cornerRadius=3
        self.SynButton.layer.borderColor=UIColor.lightGrayColor().CGColor
        self.SynButton.layer.borderWidth=1
        self.SynButton.titleLabel?.font=UIFont.systemFontOfSize(14)
        self.SynButton.layer.masksToBounds=true
        self.SynButton.setTitle("Sync Now", forState: .Normal)
        self.SynButton.setTitleColor(UIColor.blackColor(), forState: .Normal)
        self.SynButton.addTarget(self, action: #selector(saveToiCloud), forControlEvents: .TouchUpInside)
        self.view.addSubview(self.SynButton)
        
        GetNotify()
    }
    

    //把数据存储到iCloud
    func saveToiCloud() {
        
        iCloudKeyStore?.setString("Data via iCloud sync.",forKey:iCloudTextKey)
        iCloudKeyStore?.synchronize()
    }
    
    
    
    //注册接收通知，至于Post这个通知的地方肯定是iCloud了
    func GetNotify() {
        
        NSNotificationCenter.defaultCenter().addObserver(self, selector: #selector(ubiquitousKeyValueStoreDidChange(_:)), name: NSUbiquitousKeyValueStoreDidChangeExternallyNotification, object:iCloudKeyStore)
        
         iCloudKeyStore.synchronize()
    }
    

    //接收来自iCloud到通知后执行，设置textview的text
    func ubiquitousKeyValueStoreDidChange(notification:NSNotification) -> Void
    {
        if let savedString = iCloudKeyStore?.stringForKey(iCloudTextKey) {
            self.textview.text = savedString
        }
    }
    
    override func viewWillDisappear(animated: Bool) {
        
        super.viewWillDisappear(true)
        //移除通知
        NSNotificationCenter.defaultCenter().removeObserver(self, name: NSUbiquitousKeyValueStoreDidChangeExternallyNotification, object: iCloudKeyStore)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

}












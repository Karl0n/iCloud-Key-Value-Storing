//
//  GlobalPch.swift
//  SwiftDemo810
//
//  Created by 胡剑 on 16/8/10.
//  Copyright © 2016年 Karl0n. All rights reserved.
//

import Foundation
import UIKit

let kDeviceHeight = UIScreen.mainScreen().bounds.height
let kDeviceWidth = UIScreen.mainScreen().bounds.width
let URLSTR = "http://m.xincailiao.com/service/newsApi.ashx?action=news_list_ByPage2&pageSize=20&pageindex=1&category=&is_recommend=1&is_hot="
